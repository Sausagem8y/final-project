package com.basic.backupconversion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {

    static ArrayList<String> list = new ArrayList<>();
    static ArrayList<String> listPrices = new ArrayList<>();
    static ArrayList<String> listUrls = new ArrayList<>();
    static ArrayAdapter arrayAdapter;
    SQLiteDatabase myDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDatabase = this.openOrCreateDatabase("christmasList2", MODE_PRIVATE, null);
        ListView listView = findViewById(R.id.listView);

        myDatabase.execSQL("CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name VARCHAR, price DECIMAL(6,2), url VARCHAR)");

//        myDatabase.execSQL("DROP TABLE items");

        myDatabase.execSQL("INSERT INTO items (name, price, url) VALUES ('Echo Show 8', 69.99, 'https://www.amazon.com/Echo-Show-8-2nd-Gen-2021-release/dp/B084DCJKSL/ref=zg_bs_electronics_sccl_2/139-1051141-8198230?pd_rd_i=B084DCJKSL&psc=1')");
        myDatabase.execSQL("INSERT INTO items (name, price, url) VALUES ('Stranger Things Lego set', 89.99, 'https://www.junkum.com/product/lego-stranger-things-the-upside-down-75810-building-kit-2287-pieces/?attribute_style=Standard&utm_source=Google%20Shopping&utm_campaign=product&utm_medium=cpc&utm_term=92671&gclid=EAIaIQobChMIqaDbzbv8-gIVHhWtBh3hhAU9EAQYASABEgIbwPD_BwE')");
        myDatabase.execSQL("INSERT INTO items (name, price, url) VALUES ('Lego Desk Cat', 39.97, 'https://www.amazon.com/Calico-Cat-Mini-Blocks-Set/dp/B08LKT8N4Z/ref=sr_1_25?crid=9WJRVVEHDHDN&keywords=lego&qid=1666737627&qu=eyJxc2MiOiIxMC4wNCIsInFzYSI6IjkuNTgiLCJxc3AiOiI4Ljk2In0%3D&refinements=p_n_age_range%3A5442388011&rnid=165794011&s=toys-and-games&sprefix=lego%2Ctoys-and-games%2C141&sr=1-25')");


        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(arrayAdapter);

        Cursor c = myDatabase.rawQuery("SELECT * FROM items", null);

        int nameIndex = c.getColumnIndex("name");
        int priceIndex = c.getColumnIndex("price");
        int urlIndex = c.getColumnIndex("url");
        int idIndex = c.getColumnIndex("id");

        c.moveToFirst();

        while (!c.isAfterLast()) {
            Log.i("name", c.getString(nameIndex));
            Log.i("price", c.getString(priceIndex));
            Log.i("url", c.getString(urlIndex));
            Log.i("id", c.getString(idIndex));

            list.add(c.getString(nameIndex));
            listPrices.add(c.getString(priceIndex));
            listUrls.add(c.getString(urlIndex));

            Log.i("list content", list.toString());
            Log.i("price content", listPrices.toString());
            Log.i("url content", listUrls.toString());

            c.moveToNext();
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), EditItemActivity.class);
                intent.putExtra("itemId", i);
                startActivity(intent);
            }
        });

    }

//    MENU CODE


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_item_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.add_item) {
            Intent intent = new Intent(getApplicationContext(), NewItemActivity.class);
            startActivity(intent);

            arrayAdapter.notifyDataSetChanged();

            return true;
        }

        return false;
    }
}
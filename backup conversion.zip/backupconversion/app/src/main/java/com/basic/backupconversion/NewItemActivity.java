package com.basic.backupconversion;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NewItemActivity extends AppCompatActivity {

    String newItemSql = "INSERT INTO items (name, price, url) VALUES (?, ?, ?)";
    String nameString;
    String priceInt;
    String urlString;

    SQLiteStatement statement;
    SQLiteDatabase myDatabase;

    EditText nameEdit;
    EditText priceEdit;
    EditText urlEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);

        myDatabase = this.openOrCreateDatabase("christmasList2", MODE_PRIVATE, null);

        nameEdit = findViewById(R.id.nameEditText);
        priceEdit = findViewById(R.id.priceEditText);
        urlEdit = findViewById(R.id.urlEditText);

    }

    public void addItemFunction (View view) {
        nameString = nameEdit.getText().toString();
        priceInt = priceEdit.getText().toString();
        urlString = urlEdit.getText().toString();

        Log.i("4th info", nameString);
        Log.i("5th info", urlString);

        statement = myDatabase.compileStatement(newItemSql);

        statement.bindString(1, nameString);
        statement.bindString(2, priceInt);
        statement.bindString(3, urlString);
        statement.execute();

        Toast.makeText(this, "New item added, reload up to update list", Toast.LENGTH_LONG).show();
    }
}
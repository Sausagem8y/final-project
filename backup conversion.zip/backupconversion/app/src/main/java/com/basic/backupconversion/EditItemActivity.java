package com.basic.backupconversion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class EditItemActivity extends AppCompatActivity {

    int itemId;
    SQLiteDatabase myDatabase;
    String nameString;
    String priceInt;
    String urlString;

    String onEditSql = "UPDATE items SET name=? WHERE id =?";
    String priceEditSql = "UPDATE items SET price=? WHERE id=?";
    String urlEditSql = "UPDATE items SET url=? WHERE id=?";

    String deleteItemSql = "DELETE FROM items WHERE id=?";

    SQLiteStatement statement;
    SQLiteStatement priceStatement;
    SQLiteStatement urlStatement;
    SQLiteStatement deleteStatement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        EditText editName = findViewById(R.id.editName);
        EditText editPrice = findViewById(R.id.editPrice);
        EditText editUrl = findViewById(R.id.editUrl);

        Intent intent = getIntent();
        itemId = intent.getIntExtra("itemId", -1);
        myDatabase = this.openOrCreateDatabase("christmasList2", MODE_PRIVATE, null);

        Cursor c = myDatabase.rawQuery("SELECT * FROM items", null);
        c.moveToPosition(itemId);

        int priceIndex = c.getColumnIndex("price");

        if (itemId != -1) {
            editName.setText(MainActivity.list.get(itemId));
            editPrice.setText(c.getString(priceIndex));
            editUrl.setText(MainActivity.listUrls.get(itemId));

        } else {
            MainActivity.list.add("");
            itemId = MainActivity.list.size() -1;
        }

        editName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                nameString = String.valueOf(charSequence);
                MainActivity.list.set(itemId, nameString);
                MainActivity.arrayAdapter.notifyDataSetChanged();

                statement = myDatabase.compileStatement(onEditSql);

                statement.bindString(1, nameString);
                statement.bindLong(2, itemId + 1);
                statement.execute();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        editPrice.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                priceInt = String.valueOf(charSequence);

                priceStatement = myDatabase.compileStatement(priceEditSql);

                priceStatement.bindString(1, priceInt);
                priceStatement.bindLong(2, itemId + 1);
                priceStatement.execute();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        editUrl.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                urlString = String.valueOf(charSequence);

                urlStatement = myDatabase.compileStatement(urlEditSql);

                urlStatement.bindString(1, urlString);
                urlStatement.bindLong(2, itemId + 1);
                urlStatement.execute();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.delete_item_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        if (item.getItemId() == R.id.delete_item) {

            deleteStatement = myDatabase.compileStatement(deleteItemSql);

            deleteStatement.bindLong(1, itemId + 1);
            deleteStatement.execute();

            Toast.makeText(this, "Item successfully deleted, please reload app to update items", Toast.LENGTH_LONG).show();

            return true;
        }

        return false;
    }
}